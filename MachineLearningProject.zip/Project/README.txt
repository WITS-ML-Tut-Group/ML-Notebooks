`Main.pdf` is our MAIN submission for this project

In the `Notebook PDFs` folder you can see the pdf of each of our 4 algorithms.

Or you can access the notebooks directly.



NOTE:

The `Images` folder only contains some screenshot snippets used in the 
`Machine Learning Project` notebook for the `Main.pdf`.



AUTHORS
========

Arneev Singh (2180393)
Kiara Gabriel (2161334)
Shravan Singh (2173638)
Phola Bavuma (1848739)